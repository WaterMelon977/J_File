import java.util.Arrays;
import java.util.Comparator;

public class LambdaComparatorExample {
    public static void main(String[] args) {
        String[] names = {"Charlie", "Alice", "Bob"};

        // Using a lambda expression for sorting
        Arrays.sort(names, (s1, s2) -> s1.compareToIgnoreCase(s2));

       System.out.println(Arrays.toString(names)); // Output: [Alice, Bob, Charlie]
        // Alternatively, using method reference
        //Arrays.sort(names, String::compareToIgnoreCase);

       // System.out.println(Arrays.toString(names)); // Output: [Alice, Bob, Charlie]
    }
}

