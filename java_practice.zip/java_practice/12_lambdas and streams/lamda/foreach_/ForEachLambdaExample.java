
import java.util.List;

public class ForEachLambdaExample {
    public static void main(String[] args) {
        List<String> fruits = List.of("Apple", "Banana", "Cherry", "Date");

        // Using forEach with a lambda expression
        fruits.forEach(fruit -> System.out.println(fruit ));
        System.err.println();

        // Alternatively, using a method reference
        fruits.forEach(System.out::println);
    }
}
