public class LambdaRunnableExample {
    public static void main(String[] args) {
        // Using an anonymous class
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                System.out.println("Runnable using anonymous class");
            }
        };
        runnable.run();

        // Using a lambda expression
        Runnable lambdaRunnable = () -> System.out.println("Runnable using lambda expression");
        lambdaRunnable.run();
    }
}
