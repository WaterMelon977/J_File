@FunctionalInterface
interface MathOperation {
    int operate(int a, int b);
}

public class LambdaCustomFunctionalInterfaceExample {
    public static void main(String[] args) {
        // Lambda expression implementing a custom functional interface
        MathOperation addition = (a, b) -> a + b;
        MathOperation multiplication = (a, b) -> a * b;

        System.out.println("Addition: " + addition.operate(5, 3)); // Output: Addition: 8
        System.out.println("Multiplication: " + multiplication.operate(5, 3)); // Output: Multiplication: 15
    }
}
