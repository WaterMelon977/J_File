import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CountStream {
    public static void main(String[] args) {
        List<String> strings = List.of("I", "am", "a", "list", "of", "Strings");
    
        // Using forEach with a lambda expression on a Stream
        Stream<String> stream = strings.stream();

        Stream<String> limit = stream.limit(4);
  long result = limit.count();
   System.out.println("result = " + result );
     


    }
}


