import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class StreamForEachExample {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);

        // Using forEach with a lambda expression on a Stream
        Stream<Integer> numberStream = numbers.stream();
        numberStream.forEach(number -> System.out.println(number * number));
    }
}
