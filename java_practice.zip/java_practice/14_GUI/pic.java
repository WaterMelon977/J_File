import javax.swing.*;
import java.awt.*;

public class pic extends JFrame {
    public pic() {
        setTitle("Pic Drawing Example");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       // setLocationRelativeTo(null);

        // Create a custom panel for drawing
        CustomPanel1 panel1 = new CustomPanel1();
        add(panel1);

        setVisible(true);
    }
    public static void main(String[] args) {      
        new pic();
    }
}

class CustomPanel1 extends JPanel {
    @Override
    public void paintComponent(Graphics g) {
        Image image = new ImageIcon("gtaVI.jpg").getImage();
        g.drawImage(image, 3, 4, this);}
}