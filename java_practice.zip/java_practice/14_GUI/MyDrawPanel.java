import javax.swing.*;
import java.awt.*;

public class MyDrawPanel extends JFrame {
    public MyDrawPanel() {
        setTitle("Custom Drawing Example");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       // setLocationRelativeTo(null);

        // Create a custom panel for drawing
        CustomPanel panel = new CustomPanel();
        add(panel);

        setVisible(true);
    }
    public static void main(String[] args) {      
        new MyDrawPanel();
    }
}

class CustomPanel extends JPanel {
    @Override
    protected void paintComponent(Graphics g) {
        g.setColor(Color.orange);
        g.fillRect(20, 50, 100, 100);
    }
}