// Derived class
public class Student extends Person {
    private String major;

    // Constructor
    public Student(String name, int age, String major) {
        super(name, age); // Call the constructor of the superclass (Person)
        this.major = major;
    }

    // Getter
    public String getMajor() {
        return major;
    }

   // @Override
    public String toString() {
        return "Student{name='" + getName() + "', age=" + getAge() + ", major='" + major + "'}";
    }

    public static void main(String[] args) {
        Student student = new Student("Alice", 20, "Computer Science");
        System.out.println(student); // Output: Student{name='Alice', age=20, major='Computer Science'}
    }
}
