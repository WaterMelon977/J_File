public class Person {
    private String name;
    private int age;


    // No-argument Constructor (explicitly defined)
    public Person() {
        this.name = "Default Name";
        this.age = 0;
    }

    // Parameterized Constructor
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Copy Constructor
    public Person(Person other) {
        this.name = other.name;
        this.age = other.age;
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    //@Override
    public String toString() {
        return "Person{name='" + name + "', age=" + age + "}";
    }

    public static void main(String[] args) {
        // Using the default constructor
        Person person1 = new Person();
        System.out.println(person1); // Output: Person{name='Default Name', age=0}

        // Using the parameterized constructor
        Person person2 = new Person("Alice", 30);
        System.out.println(person2); // Output: Person{name='Alice', age=30}

        // Using the copy constructor
        Person person3 = new Person(person2);
        System.out.println(person3); // Output: Person{name='Alice', age=30}

        // Modifying the copied object
        person3.setName("Bob");
        System.out.println(person3); // Output: Person{name='Bob', age=30}
        System.out.println(person2); // Output: Person{name='Alice', age=30}
    }
}
