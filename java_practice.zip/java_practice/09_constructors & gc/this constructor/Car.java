public class Car {
    private String brand;
    private String model;
    private int year;

    // No-argument constructor
    public Car() {
        this("Unknown", "Unknown", 0); // Call the parameterized constructor
    }

    // Constructor with brand and model
    public Car(String brand, String model) {
        this(brand, model, 0); // Call the parameterized constructor
    }

    // Constructor with brand, model, and year
    public Car(String brand, String model, int year) {
        this.brand = brand;
        this.model = model;
        this.year = year;
    }

    //@Override
    public String toString() {
        return "Car{brand='" + brand + "', model='" + model + "', year=" + year + "}";
    }

    public static void main(String[] args) {
        Car car1 = new Car();
        Car car2 = new Car("Toyota", "Corolla");
        Car car3 = new Car("Honda", "Civic", 2020);

        System.out.println(car1); // Output: Car{brand='Unknown', model='Unknown', year=0}
        System.out.println(car2); // Output: Car{brand='Toyota', model='Corolla', year=0}
        System.out.println(car3); // Output: Car{brand='Honda', model='Civic', year=2020}
    }
}
