import java.io.*;
public class square1 implements Serializable {

    private int width;
    private int height;

    public square1(int width, int height) {
      this.width = width;
      this.height = height;
    }

    public static void main(String[] args) {
      square1 mySquare = new square1(50, 20);



      try {
        FileOutputStream fs = new FileOutputStream("foo.ser");
        ObjectOutputStream os = new ObjectOutputStream(fs);
        os.writeObject(mySquare);


        os.close();
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }
 }




