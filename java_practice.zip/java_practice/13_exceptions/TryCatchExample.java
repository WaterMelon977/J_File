public class TryCatchExample {
    public static void main(String[] args) {
        try {
            // Code that may throw an exception
            int divisionResult = divide(10, 0);
            System.out.println("Division result: " + divisionResult);
        } catch (ArithmeticException e) {
            // Handling the exception
            System.out.println("Error: Division by zero is not allowed.");
        }
    }

    public static int divide(int a, int b) {
        return a / b; // This will throw ArithmeticException if b is 0
    }
}
