import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.lang.ArithmeticException;

public class ExceptionHandlingExample {

    public static void main(String[] args) {
        try {
            processFileAndDivide("nonexistent_file.txt", 10, 0);
        } catch (FileNotFoundException e) {
            System.out.println("Caught FileNotFoundException: " + e.getMessage());
        } catch (ArithmeticException e) {
            System.out.println("Caught ArithmeticException: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed.");
        }
    }

    public static void processFileAndDivide(String filename, int num1, int num2) throws FileNotFoundException, ArithmeticException {
        // Attempt to open and read the file
        File file = new File(filename);
        Scanner scanner = new Scanner(file);

        // Perform a division operation
        int result = divide(num1, num2);
        System.out.println("Division result: " + result);

        // Simulate reading from the file (dummy operation)
        while (scanner.hasNextLine()) {
            System.out.println(scanner.nextLine());
        }

        scanner.close();
    }

    public static int divide(int a, int b) throws ArithmeticException {
        if (b == 0) {
            throw new ArithmeticException("Cannot divide by zero.");
        }
        return a / b;
    }
}
