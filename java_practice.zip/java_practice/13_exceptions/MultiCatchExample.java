public class MultiCatchExample {
    public static void main(String[] args) {
        try {
            int[] numbers = {1, 2, 3};
            System.out.println(numbers[5]); // ArrayIndexOutOfBoundsException

            int result = divide(10, 0); // ArithmeticException
            System.out.println("Result: " + result);

        } catch (ArrayIndexOutOfBoundsException  e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
        catch (Exception  e1) {
            System.out.println("An error occurred: " + e1.getMessage());
        }
    }
    
    public static int divide(int a, int b) {
        return a / b;
    }
}
