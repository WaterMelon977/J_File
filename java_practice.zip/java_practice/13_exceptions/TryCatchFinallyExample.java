import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class TryCatchFinallyExample {
    public static void main(String[] args) {
        FileInputStream inputStream = null;

        try {
            // Opening a file that doesn't exist will throw an IOException
            File file = new File("nonexistent_file.txt");
            inputStream = new FileInputStream(file);

            // Read data from the file (not actually happening here)
            // int data = inputStream.read();

        } catch (IOException e) {
            // Handling the exception
            System.out.println("Error: " + e.getMessage());
        } finally {
            // Closing the input stream if it was opened
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            System.out.println("Finally block executed.");
        }
    }
}
