public class ArrayExample {
    public static void main(String[] args) {
        // Creating an array of integers
        int[] numbers = {1, 2, 3, 4, 5};

        // Accessing elements
        System.out.println("First element: " + numbers[0]); // Output: First element: 1

        // Modifying elements
        numbers[0] = 10;
        System.out.println("Modified first element: " + numbers[0]); // Output: Modified first element: 10
        System.out.println(numbers);

        // Iterating over the array
        System.out.println("Array elements:");
        for (int number : numbers) {
            System.out.println(number);
        }
    }
}
