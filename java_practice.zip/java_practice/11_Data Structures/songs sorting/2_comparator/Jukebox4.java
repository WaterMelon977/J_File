import java.util.*;
public class Jukebox4 {
 public static void main(String[] args) {
   new Jukebox4().go();
 }
 public void go() {
   List<SongV2> songList = MockSongs.getSongsV2();
   System.out.println(songList);
   Collections.sort(songList); //uses compareTo
   System.out.println(songList);

   ArtistCompare artistCompare = new ArtistCompare();
   songList.sort(artistCompare); // .sort(custom comparator)
   System.out.println(songList);
 }
}
class ArtistCompare implements Comparator<SongV2> {
 public int compare(SongV2 one, SongV2 two) {
   return one.getArtist().compareTo(two.getArtist());
 }
}
