
import java.util.*;
public class TreeSet1_bpm {
    public static void main(String[] args) {
        new TreeSet1_bpm().go();
      }
      public void go() {
        List<SongV3> songList = MockSongs.getSongsV3();
        System.out.println(songList);
        songList.sort((one, two) -> one.getTitle().compareTo(two.getTitle()));
        System.out.println(songList);
        
        
        Set<SongV3> songSet1 = new TreeSet<>((o1, o2) -> (o1.getBpm() - o2.getBpm())); 
        // Yep, another lambda for  sorting. This one sorts  by BPM. Remember,  this lambda implements  Comparator.
      songSet1.addAll(songList);
      System.out.println(songSet1);


      }
}
