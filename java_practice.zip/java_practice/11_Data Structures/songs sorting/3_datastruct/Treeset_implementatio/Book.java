 class Book implements Comparable<Book> {
  public String title;
  public Book(String t) {
    title = t;
  }
  public int compareTo(Book other) {
    return title.compareTo(other.title);
  }

  public String toString()
  {return title;
  }
 }