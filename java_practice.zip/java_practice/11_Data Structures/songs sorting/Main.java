import java.util.List;

public class Main {
    public static void main(String[] args) {
       // MockSongs m = new MockSongs();
        List<String> l=  MockSongs.getSongStrings();
        System.out.println(""+l);
    }
}
