import java.util.ArrayList;
import java.util.List;

public class ArrayListExample {
    public static void main(String[] args) {
        // Creating an ArrayList of Strings
        List<String> fruits = new ArrayList<>();

        // Adding elements to the ArrayList
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Orange");

        // Accessing elements
        System.out.println("First fruit: " + fruits.get(0)); // Output: First fruit: Apple

        // Modifying elements
        fruits.set(1, "Mango");
        System.out.println("Modified list: " + fruits); // Output: Modified list: [Apple, Mango, Orange]

        // Removing an element
        fruits.remove(2);
        System.out.println("List after removal: " + fruits); // Output: List after removal: [Apple, Mango]

        // Iterating over the ArrayList
        System.out.println("Iterating over list:");
        for (String fruit : fruits) {
            System.out.println(fruit);
        }
    }
}
