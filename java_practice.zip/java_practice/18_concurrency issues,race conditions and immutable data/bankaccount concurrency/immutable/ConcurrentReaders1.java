import java.util.concurrent.*;
import java.util.List;
import java.util.ArrayList;
import java.time.*;
import java.time.format.*;


public class ConcurrentReaders1 {

    
    public static void main(String[] args) {
  
        List<Chat> chatHistory = new CopyOnWriteArrayList<>();
   ExecutorService executor = Executors.newFixedThreadPool(3);

   for (int i = 0; i < 5; i++) {
    executor.execute(() -> chatHistory.add(new Chat("Hi there!")));
    executor.execute(() -> System.out.println(chatHistory));
    executor.execute(() -> System.out.println(chatHistory));
   }

   executor.shutdown();
}
}


final class Chat {
    private final String message;
    private final LocalDateTime timestamp;
  
  
    public Chat(String message) {
      this.message = message;
      timestamp = LocalDateTime.now();
    }
  
    public String toString() {
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
      String time = timestamp.format(formatter);
      return time + " " + message;
    }
   }
