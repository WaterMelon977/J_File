import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JTextFieldExample extends JFrame {
    private JTextFieldExample() {
        // Set up the frame
        setTitle("JTextField Example");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create components
        JLabel label = new JLabel("Enter your name:");
        JTextField textField = new JTextField(15); // JTextField with 15 columns
        JButton button = new JButton("Submit");
        JLabel outputLabel = new JLabel();

        // Set up the layout and add components
        setLayout(new FlowLayout());
        add(label);
        add(textField);
        add(button);
        add(outputLabel);

        // Add action listener to the button
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = textField.getText();
                outputLabel.setText("Hello, " + name + "!");
            }
        });

        // Make the frame visible
        setVisible(true);
    }

    public static void main(String[] args) {
        // // Run the GUI in the Event Dispatch Thread (EDT)
        // SwingUtilities.invokeLater(new Runnable() {
        //     @Override
        //     public void run() {
        //         new JTextFieldExample();
        //     }
        // });

        JTextFieldExample J =new JTextFieldExample();
        
    }
}
