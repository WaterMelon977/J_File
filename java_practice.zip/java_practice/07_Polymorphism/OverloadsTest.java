

   public class OverloadsTest{
   public static void main(String[] args) {
    Overloads a = new Overloads();
    Overloads b = new Overloads();
    //Overloads c = new Overloads();
    a.setUniqueID("S783");
    b.setUniqueID(56677); 

    a.getUniqueID();
    b.getUniqueID();
   }
  }




   
   
   
   
 