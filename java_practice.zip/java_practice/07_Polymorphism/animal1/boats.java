public class boats {
    private int length ;

    public void setLength ( int len ) {
         length = len;
      }

      public int getLength() {
    return length ;
      }

      public void move() {
    System.out.print("drift  ");
      }
}
class Rowboat extends boats {
    public void rowTheBoat() {
         System.out.print("stroke natasha");
      }
    }

    class TestBoats {
        public static void main(String[] args){
        boats b1 = new boats();
             Sailboat b2 = new Sailboat();
             Rowboat b3 = new Rowboat();
             b2.setLength(32);
             b1.move();
             b3.move();
             b2.move();
             b3.rowTheBoat();
        }
        }

        class Sailboat extends boats {
            public void move() {
                 System.out.print("hoist sail ");
            }
            }
