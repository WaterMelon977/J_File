// File: Main.java
public class Main {
    public static void main(String[] args) {
        Vehicle genericVehicle = new Vehicle("Generic Brand");
        genericVehicle.honk(); // Output: Vehicle honk
        
        Car car = new Car("Toyota", 4);
        car.honk(); // Output: Car honk
        System.out.println(car.getBrand()); // Output: Toyota
        System.out.println(car.getDoors()); // Output: 4
        
        Bicycle bicycle = new Bicycle("Giant", true);
        bicycle.honk(); // Output: Bicycle bell ring
        System.out.println(bicycle.getBrand()); // Output: Giant
        System.out.println(bicycle.hasBell());  // Output: true
    }
}
