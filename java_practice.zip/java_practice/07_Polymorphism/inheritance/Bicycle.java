// File: Bicycle.java
public class Bicycle extends Vehicle {
    private boolean hasBell;
    
    public Bicycle(String brand, boolean hasBell) {
        super(brand);
        this.hasBell = hasBell;
    }
    
   // @Override
    public void honk() {
        System.out.println("Bicycle bell ring");
    }
    
    public boolean hasBell() {
        return hasBell;
    }
}
