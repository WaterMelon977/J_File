// File: Vehicle.java
public class Vehicle {
    private String brand;
    
    public Vehicle(String brand) {
        this.brand = brand;
    }
    
    public void honk() {
        System.out.println("Vehicle honk");
    }
    
    public String getBrand() {
        return brand;
    }
}
