// File: Car.java
public class Car extends Vehicle {
    private int doors;
    
    public Car(String brand, int doors) {
        super(brand);
        this.doors = doors;
    }
    
    //@Override
    public void honk() {
        System.out.println("Car honk");
    }
    
    public int getDoors() {
        return doors;
    }
}
