// File: Main.java
public class Main {
    public static void main(String[] args) {
        // Create an Animal object
        Animal genericAnimal = new Animal("Generic Animal", 5);
        genericAnimal.makeSound(); // Output: Some generic animal sound
        
        // Create a Dog object
        Dog dog = new Dog("Buddy", 3);
        dog.makeSound(); // Output: Bark
        dog.fetch();     // Output: Fetching the ball
        Animal d;
        d= new Dog ("Sam",5);

        
        // Accessing inherited methods
        System.out.println(dog.getName()); // Output: Buddy
        System.out.println(dog.getAge());  // Output: 3
        d.makeSound(); // Output: Bark

    }
}
 