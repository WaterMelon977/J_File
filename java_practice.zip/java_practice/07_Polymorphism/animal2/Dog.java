public class Dog extends Animal {
    // Constructor
    public Dog(String name, int age) {
        super(name, age); // Call the superclass constructor
    }
    
    // Overriding the makeSound method
    //@Override
    public void makeSound() {
        System.out.println("Bark");
    }
    
    // Additional method
    public void fetch() {
        System.out.println("Fetching the ball");
    }
}
