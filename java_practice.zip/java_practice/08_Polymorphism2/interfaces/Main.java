// File: Main.java
public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog("Buddy", 3);
        dog.makeSound(); // Output: Buddy says: Bark
        dog.sleep();     // Output: Buddy is sleeping.
        dog.play();      // Output: Buddy is playing fetch.
        dog.beFriendly();// Output: Buddy is being friendly.

        Cat cat = new Cat("Whiskers", 2);
        cat.makeSound(); // Output: Whiskers says: Meow
        cat.sleep();     // Output: Whiskers is sleeping.
        cat.play();      // Output: Whiskers is playing with a ball of yarn.
        cat.beFriendly();// Output: Whiskers is being friendly.
    }
}
