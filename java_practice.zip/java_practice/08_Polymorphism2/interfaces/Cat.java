// File: Cat.java
public class Cat extends Animal implements Pet {
    public Cat(String name, int age) {
        super(name, age);
    }

    @Override
    public void makeSound() {
        System.out.println(getName() + " says: Meow");
    }

    @Override
    public void play() {
        System.out.println(getName() + " is playing with a ball of yarn.");
    }

    @Override
    public void beFriendly() {
        System.out.println(getName() + " is being friendly.");
    }
}