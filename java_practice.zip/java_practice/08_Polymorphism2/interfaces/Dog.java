// File: Dog.java
public class Dog extends Animal implements Pet {
    public Dog(String name, int age) {
        super(name, age);
    }

    @Override
    public void makeSound() {
        System.out.println(getName() + " says: Bark");
    }

    @Override
    public void play() {
        System.out.println(getName() + " is playing fetch.");
    }

    @Override
    public void beFriendly() {
        System.out.println(getName() + " is being friendly.");
    }
}

