// File: Pet.java
public interface Pet {
    void play();
    void beFriendly();
}
