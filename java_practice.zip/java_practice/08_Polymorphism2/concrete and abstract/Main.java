// File: Main.java
public class Main {
    public static void main(String[] args) {
        Animal dog = new Dog("Buddy", 3);
        dog.makeSound(); // Output: Buddy says: Bark
        dog.sleep();     // Output: Buddy is sleeping.

        Animal cat = new Cat("Whiskers", 2);
        cat.makeSound(); // Output: Whiskers says: Meow
        cat.sleep();     // Output: Whiskers is sleeping.
    }
}
    