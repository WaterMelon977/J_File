public class DogTestDrive {
    public static void main(String[] args) {
        dog d = new dog();
        d.size = 40;
        d.breed= "German Sherperd";
        d.name= "Lola";
        d.bark();
      System.out.println("This is a "+ d.breed +" and its name is "+   d.name );
    }
}
