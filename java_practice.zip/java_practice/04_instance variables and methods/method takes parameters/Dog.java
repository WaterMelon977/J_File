class Dog {
    int size;
    String name;
    void bark(int numOfBarks) {
        System.out.println("Dog"+size+"says");

        while (numOfBarks > 0) {
        System.out.println("ruff");
       numOfBarks = numOfBarks - 1;
        } 
    }
     }