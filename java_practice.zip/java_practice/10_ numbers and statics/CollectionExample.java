import java.util.ArrayList;

public class CollectionExample {
    public static void main(String[] args) {
        // Creating an ArrayList to hold integers
        ArrayList<Integer> intList = new ArrayList<>();

        // Autoboxing: adding primitives to the list
        intList.add(10); // Autoboxing int to Integer
        intList.add(20);
        intList.add(30);

        // Accessing elements (unboxing)
        int sum = 0;
        for (Integer num : intList) {
            sum += num; // Unboxing Integer to int
        }

        System.out.println("Sum: " + sum); // Output: Sum: 60
    }
}
