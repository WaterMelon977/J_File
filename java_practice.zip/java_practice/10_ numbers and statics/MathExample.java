public class MathExample {
    public static void main(String[] args) {
        // Absolute value
        int x = -10;
        System.out.println("Absolute value of " + x + " is: " + Math.abs(x)); // Output: 10

        // Maximum and minimum
        int a = 5;
        int b = 10;
        System.out.println("Maximum of " + a + " and " + b + " is: " + Math.max(a, b)); // Output: 10
        System.out.println("Minimum of " + a + " and " + b + " is: " + Math.min(a, b)); // Output: 5

        // Ceiling and floor
        double y = 7.8;
        System.out.println("Ceiling of " + y + " is: " + Math.ceil(y)); // Output: 8.0
        System.out.println("Floor of " + y + " is: " + Math.floor(y)); // Output: 7.0

        // Rounding
        System.out.println("Rounding " + y + " gives: " + Math.round(y)); // Output: 8

        // Trigonometric functions
        double angle = Math.toRadians(45); // Converting degrees to radians
        System.out.println("Sine of 45 degrees is: " + Math.sin(angle)); // Output: 0.7071067811865475
        System.out.println("Cosine of 45 degrees is: " + Math.cos(angle)); // Output: 0.7071067811865476
        System.out.println("Tangent of 45 degrees is: " + Math.tan(angle)); // Output: 0.9999999999999999

        // Exponential and logarithmic functions
        double value = 2.0;
        System.out.println("Exponential of " + value + " is: " + Math.exp(value)); // Output: 7.3890560989306495
        System.out.println("Natural logarithm of " + value + " is: " + Math.log(value)); // Output: 0.6931471805599453
        System.out.println("Base 10 logarithm of " + value + " is: " + Math.log10(value)); // Output: 0.3010299956639812

        // Power and square root
        double base = 3.0;
        double exponent = 4.0;
        System.out.println(base + " raised to the power of " + exponent + " is: " + Math.pow(base, exponent)); // Output: 81.0
        System.out.println("Square root of " + base + " is: " + Math.sqrt(base)); // Output: 1.7320508075688772

        // Random number generation
        double randomValue = Math.random();
        System.out.println("Random value between 0.0 and 1.0 is: " + randomValue);
        int i = (int) (10*Math.random()) ;
        System.out.println("Random integer between 0 and 9: " + i);



        // Constants
        System.out.println("Value of PI is: " + Math.PI); // Output: 3.141592653589793
        System.out.println("Value of E is: " + Math.E); // Output: 2.718281828459045
    }
}
