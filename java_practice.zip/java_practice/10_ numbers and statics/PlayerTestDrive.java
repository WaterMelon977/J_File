class Player {
    static int playerCount = 0;
    private String name;
    public Player(String n) {
      name = n;
      playerCount++;
    }
   }


   public class PlayerTestDrive {
    public static void main(String[] args) {
      System.out.println(Player.playerCount);
      Player one = new Player("Tiger Woods");
      Player two = new Player("Sumanth Ravuri");
      System.out.println(Player.playerCount);
    }
   }
   