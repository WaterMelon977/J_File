public class UnboxingExample {
    public static void main(String[] args) {
        // Autoboxing
        Integer integerObject = 10;

        // Unboxing: converting Integer to int
        int primitiveInt = integerObject;

        // Autoboxing
        Double doubleObject = 3.14;

        // Unboxing: converting Double to double
        double primitiveDouble = doubleObject;

        System.out.println("Primitive int: " + primitiveInt);
        System.out.println("Primitive double: " + primitiveDouble);
    }
}
