public class AutoboxingExample {
    public static void main(String[] args) {
        // Autoboxing: converting int to Integer
        Integer integerObject = 10;

        // Autoboxing: converting double to Double
        Double doubleObject = 3.14;
        int s = integerObject; 

        System.out.println("Integer object: " + integerObject);
        System.out.println("Double object: " + doubleObject);
        System.out.println("int type :"+s );
    }
}
