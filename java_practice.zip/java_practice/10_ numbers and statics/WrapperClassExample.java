public class WrapperClassExample {
    public static void main(String[] args) {
        // Parsing a string to a primitive
        int parsedInt = Integer.parseInt("123");
        System.out.println("Parsed int: " + parsedInt); // Output: Parsed int: 123

        // Converting a primitive to a string
        String intString = Integer.toString(123);
        System.out.println("Integer as String: " + intString); // Output: Integer as String: 123

        // ValueOf method to create a wrapper object
        Integer integerObject = Integer.valueOf(123);
        System.out.println("Integer object: " + integerObject); // Output: Integer object: 123

        // Converting a string to a Double
        Double doubleObject = Double.valueOf("3.14");
        System.out.println("Double object: " + doubleObject); // Output: Double object: 3.14

        // Checking the value of a Boolean object
        Boolean booleanObject = Boolean.valueOf("true");
        System.out.println("Boolean object: " + booleanObject); // Output: Boolean object: true
    }
}
